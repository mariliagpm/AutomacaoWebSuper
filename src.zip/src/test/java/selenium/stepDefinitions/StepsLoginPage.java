package selenium.stepDefinitions;

import org.apache.log4j.Logger;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import selenium.SeleniumTestWrapper;
import selenium.interactions.HomeInteraction;
import selenium.interactions.LoginInteraction;


public class StepsLoginPage {

	Logger log = Logger.getLogger(StepsLoginPage.class); // Classse de Log
	String browserName = "";
	LoginInteraction  loginInteraction;// Classe responsável
									// pelos steps de
									// entrada na home
									// page do sistema
	
	

	String pathLogFinal = "";


	
	@Given("^I use my cpf as \"([^\"]*)\"$")
	public void i_use_my_cpf_as(String cpf) throws Throwable {
		loginInteraction = PageFactory.initElements(SeleniumTestWrapper.getDriver(), LoginInteraction.class);
		loginInteraction.sendCpf(cpf);
	}
	
	

	@Given("^I click at Continuar button$")
	public void i_click_at_Continuar_button() throws Throwable {
		loginInteraction.clickLoginPage();
	}

	@Given("^I send my passoword as \"([^\"]*)\"$")
	public void i_send_my_passoword_as(String password) throws Throwable {
		loginInteraction.sendPassword(password);
	}

	
	@Given("^I click at Entrar button$")
	public void i_click_at_Entrar_button() throws Throwable {
		loginInteraction.clickEntrarButton();
	}

}