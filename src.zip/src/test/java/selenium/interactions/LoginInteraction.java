package selenium.interactions;


import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import selenium.SeleniumTestWrapper;
import selenium.pageobjects.LoginPage;

public class LoginInteraction extends LoginPage{

	private final Logger log = Logger.getLogger(LoginInteraction.class);
	
	
	public LoginInteraction(final WebDriver driver) {
		super(driver);
	}

	
	
	

	public void sendCpf(String cpf) throws Exception {
		try { 
			SeleniumTestWrapper.takeScreenshot();
			sendElemet(userCpf, cpf);
			SeleniumTestWrapper.takeScreenshot();
			log.info("User send the email");
		} catch (Exception e) {
			log.error("It was not possible to send user's cpf");
			log.error(e.getMessage());
			log.error(e.getStackTrace());
			throw e;
		}
		
	}
	
	
	public void clickLoginPage() throws Exception {
		try { 
			SeleniumTestWrapper.takeScreenshot();
			waitToElementAndClick(butttonContinuar);
			log.info("User is in the Home Page");
			SeleniumTestWrapper.takeScreenshot();
		} catch (Exception e) {
			log.error("It was not possible to redirect to HomePage");
			log.error(e.getMessage());
			log.error(e.getStackTrace());
			throw e;
		}
	}
	
	public void sendPassword(String password) throws Exception {
		try { 
			Thread.sleep(1500);	
			char[] pa=password.toCharArray();
			for(int i=0;i<password.length();i++) {
				
					if(pa[i]=='0') 
					waitToElementAndClick(button0);
				
					if(pa[i]=='1') 
						waitToElementAndClick(button1);

					if(pa[i]=='2') 
						waitToElementAndClick(button2);

					if(pa[i]=='3') 
						waitToElementAndClick(button3);

					if(pa[i]=='4') 
						waitToElementAndClick(button4);

					if(pa[i]=='5') 
						waitToElementAndClick(button5);

					if(pa[i]=='6') 
						waitToElementAndClick(button6);

					if(pa[i]=='7') 
						waitToElementAndClick(button7);

					if(pa[i]=='8') 
						waitToElementAndClick(button8);

					if(pa[i]=='9') 
						waitToElementAndClick(button9);
					Thread.sleep(1000);			
				
			}
			
			SeleniumTestWrapper.takeScreenshot();
			log.info("User is in the Home Page");
			SeleniumTestWrapper.takeScreenshot();
		} catch (Exception e) {
			log.error("It was not possible to redirect to HomePage");
			log.error(e.getMessage());
			log.error(e.getStackTrace());
			throw e;
		}
	}
	
	public void clickEntrarButton() throws Exception {
		try { 
			SeleniumTestWrapper.takeScreenshot();
			Thread.sleep(3000);
			waitToElementAndClick(botaoEntrar);
			log.info("User is in the Home Page");
			SeleniumTestWrapper.takeScreenshot();
		} catch (Exception e) {
			log.error("It was not possible to redirect to HomePage");
			log.error(e.getMessage());
			log.error(e.getStackTrace());
			throw e;
		}
	}
}
