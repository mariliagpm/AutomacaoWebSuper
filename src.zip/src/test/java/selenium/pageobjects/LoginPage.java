package selenium.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage extends Pages {
	
	@FindBy(how = How.XPATH, using = "/html/body/div[1]/div[2]/div[2]/div/div/div/form/div[1]/div/input")
    public WebElement userCpf;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"root\"]/div[2]/div[2]/div/div/div/form/div[2]/div[2]/button/span[1]")
    public WebElement butttonContinuar;
	
	@FindBy(how = How.XPATH, using = "/html/body/div[1]/div[2]/div[2]/div/div/div/div/div[2]/div[1]/div/div[1]/div/div[2]/div[4]/button[1]")
    public WebElement button0;

	@FindBy(how = How.XPATH, using = "/html/body/div[1]/div[2]/div[2]/div/div/div/div/div[2]/div[1]/div/div[1]/div/div[2]/div[1]/button[1]")
    public WebElement button1;

	@FindBy(how = How.XPATH, using = "/html/body/div[1]/div[2]/div[2]/div/div/div/div/div[2]/div[1]/div/div[1]/div/div[2]/div[1]/button[2]")
    public WebElement button2;

	@FindBy(how = How.XPATH, using = "/html/body/div[1]/div[2]/div[2]/div/div/div/div/div[2]/div[1]/div/div[1]/div/div[2]/div[1]/button[3]")
    public WebElement button3;
	
	@FindBy(how = How.XPATH, using = "/html/body/div[1]/div[2]/div[2]/div/div/div/div/div[2]/div[1]/div/div[1]/div/div[2]/div[2]/button[1]")
    public WebElement button4;
	
	@FindBy(how = How.XPATH, using = "/html/body/div[1]/div[2]/div[2]/div/div/div/div/div[2]/div[1]/div/div[1]/div/div[2]/div[2]/button[2]")
    public WebElement button5;
	
	@FindBy(how = How.XPATH, using = "/html/body/div[1]/div[2]/div[2]/div/div/div/div/div[2]/div[1]/div/div[1]/div/div[2]/div[2]/button[3]")
    public WebElement button6;
	
	@FindBy(how = How.XPATH, using = "/html/body/div[1]/div[2]/div[2]/div/div/div/div/div[2]/div[1]/div/div[1]/div/div[2]/div[3]/button[1]")
    public WebElement button7;
	
	@FindBy(how = How.XPATH, using = "/html/body/div[1]/div[2]/div[2]/div/div/div/div/div[2]/div[1]/div/div[1]/div/div[2]/div[3]/button[2]")
    public WebElement button8;
	
	@FindBy(how = How.XPATH, using = "/html/body/div[1]/div[2]/div[2]/div/div/div/div/div[2]/div[1]/div/div[1]/div/div[2]/div[3]/button[3]")
    public WebElement button9;
	
	
	@FindBy(how = How.XPATH, using = "/html/body/div[1]/div[2]/div[2]/div/div/div/div/div[2]/div[1]/div/div[2]/div/div[3]/button")
    public WebElement botaoEntrar;
	
	public LoginPage(final WebDriver driver) {
		super(driver);
	}

	public void open() {
		super.open();
	}

}
