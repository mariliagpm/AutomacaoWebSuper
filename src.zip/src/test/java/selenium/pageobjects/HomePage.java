package selenium.pageobjects;

import org.openqa.selenium.WebDriver;

public class HomePage extends Pages {


	
	
	
	
	public HomePage(final WebDriver driver) {
		super(driver);
	}

	public void open() {
		super.open();
	}

}
